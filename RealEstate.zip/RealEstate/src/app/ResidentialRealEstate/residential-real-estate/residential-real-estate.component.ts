import { Component } from '@angular/core';

@Component({
  selector: 'app-residential-real-estate',
  standalone: true,
  imports: [],
  templateUrl: './residential-real-estate.component.html',
  styleUrl: './residential-real-estate.component.css'
})
export class ResidentialRealEstateComponent {

}
