import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResidentialRealEstateComponent } from './residential-real-estate.component';

describe('ResidentialRealEstateComponent', () => {
  let component: ResidentialRealEstateComponent;
  let fixture: ComponentFixture<ResidentialRealEstateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ResidentialRealEstateComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResidentialRealEstateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
