import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommercialrsComponent } from "./CommercialRS/commercialrs/commercialrs.component";
import { ForbesGlobalPropertyComponent } from "./ForbesGlobalProperty/forbes-global-property/forbes-global-property.component";
import { ResidentialRealEstateComponent } from "./ResidentialRealEstate/residential-real-estate/residential-real-estate.component";
import { RealEstateComponent } from "./RealEstate/real-estate/real-estate.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, CommercialrsComponent, ForbesGlobalPropertyComponent, ResidentialRealEstateComponent, RealEstateComponent]
})
export class AppComponent {
  title = 'RealEstate';
}
