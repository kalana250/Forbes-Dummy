import { Component } from '@angular/core';

@Component({
  selector: 'app-real-estate',
  standalone: true,
  imports: [],
  templateUrl: './real-estate.component.html',
  styleUrl: './real-estate.component.css'
})
export class RealEstateComponent {

}
