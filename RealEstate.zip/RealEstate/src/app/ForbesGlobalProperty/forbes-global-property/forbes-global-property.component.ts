import { Component } from '@angular/core';

@Component({
  selector: 'app-forbes-global-property',
  standalone: true,
  imports: [],
  templateUrl: './forbes-global-property.component.html',
  styleUrl: './forbes-global-property.component.css'
})
export class ForbesGlobalPropertyComponent {

}
