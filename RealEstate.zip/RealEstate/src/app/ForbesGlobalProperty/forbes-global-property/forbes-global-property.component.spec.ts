import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForbesGlobalPropertyComponent } from './forbes-global-property.component';

describe('ForbesGlobalPropertyComponent', () => {
  let component: ForbesGlobalPropertyComponent;
  let fixture: ComponentFixture<ForbesGlobalPropertyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ForbesGlobalPropertyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForbesGlobalPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
