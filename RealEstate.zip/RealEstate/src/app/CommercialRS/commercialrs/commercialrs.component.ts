import { Component } from '@angular/core';

@Component({
  selector: 'app-commercialrs',
  standalone: true,
  imports: [],
  templateUrl: './commercialrs.component.html',
  styleUrl: './commercialrs.component.css'
})
export class CommercialrsComponent {

}
