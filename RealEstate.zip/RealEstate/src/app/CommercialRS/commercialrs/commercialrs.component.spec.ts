import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommercialrsComponent } from './commercialrs.component';

describe('CommercialrsComponent', () => {
  let component: CommercialrsComponent;
  let fixture: ComponentFixture<CommercialrsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CommercialrsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CommercialrsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
