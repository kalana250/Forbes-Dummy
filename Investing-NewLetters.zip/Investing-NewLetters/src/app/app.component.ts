import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { INVESTINGNEWLETTERSComponent } from './investing-newletters/investing-newletters.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,INVESTINGNEWLETTERSComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Investing-NewLetters';
}
