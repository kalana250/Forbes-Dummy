import { Component } from '@angular/core';

@Component({
  selector: 'app-investing-newletters',
  standalone: true,
  imports: [],
  templateUrl: './investing-newletters.component.html',
  styleUrl: './investing-newletters.component.css'
})
export class INVESTINGNEWLETTERSComponent {
  bodyImageURL:string='https://imageio.forbes.com/specials-images/imageserve/663aa0fba7f0aaa8a73b6ab2/0x0.jpg?format=jpg';
  bestimage:string='https://imageio.forbes.com/specials-images/imageserve/63f8db12caf334183e093b40/0x0.jpg?format=jpg';
  Stockimage:string='https://imageio.forbes.com/specials-images/imageserve/63f8eeac1a7e124ff88ba854/0x0.jpg?format=jpg&crop=611,344,x0,y-0,safe';
  Forbesimage:string='https://imageio.forbes.com/specials-images/imageserve/63f8dcdb61f7ea1ca08ba852/0x0.jpg?format=jpg&crop=611,344,x0,y32,safe';

}
