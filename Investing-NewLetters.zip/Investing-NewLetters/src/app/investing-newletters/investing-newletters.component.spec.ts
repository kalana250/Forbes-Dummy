import { ComponentFixture, TestBed } from '@angular/core/testing';

import { INVESTINGNEWLETTERSComponent } from './investing-newletters.component';

describe('INVESTINGNEWLETTERSComponent', () => {
  let component: INVESTINGNEWLETTERSComponent;
  let fixture: ComponentFixture<INVESTINGNEWLETTERSComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [INVESTINGNEWLETTERSComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(INVESTINGNEWLETTERSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
