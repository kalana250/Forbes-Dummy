import { Component } from '@angular/core';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [],
  templateUrl: './report.component.html',
  styleUrl: './report.component.css'
})
export class REPORTComponent {
  mapimage:string="https://res.cloudinary.com/hynomj8e0/image/upload/geptf3jaf2lu0plfgx3k.jpg";

}
