import { ComponentFixture, TestBed } from '@angular/core/testing';

import { REPORTComponent } from './report.component';

describe('REPORTComponent', () => {
  let component: REPORTComponent;
  let fixture: ComponentFixture<REPORTComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [REPORTComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(REPORTComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
