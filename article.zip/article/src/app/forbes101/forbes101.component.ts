import { Component } from '@angular/core';

@Component({
  selector: 'app-forbes101',
  standalone: true,
  imports: [],
  templateUrl: './forbes101.component.html',
  styleUrl: './forbes101.component.css'
})
export class Forbes101Component {

}
