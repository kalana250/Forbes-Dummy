import { Component } from '@angular/core';

@Component({
  selector: 'app-fw-collection',
  standalone: true,
  imports: [],
  templateUrl: './fw-collection.component.html',
  styleUrl: './fw-collection.component.css'
})
export class FwCollectionComponent {

}
