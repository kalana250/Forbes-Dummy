import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FwCollectionComponent } from './fw-collection.component';

describe('FwCollectionComponent', () => {
  let component: FwCollectionComponent;
  let fixture: ComponentFixture<FwCollectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FwCollectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FwCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
