import { ComponentFixture, TestBed } from '@angular/core/testing';

import { U30CollectionComponent } from './u30-collection.component';

describe('U30CollectionComponent', () => {
  let component: U30CollectionComponent;
  let fixture: ComponentFixture<U30CollectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [U30CollectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(U30CollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
