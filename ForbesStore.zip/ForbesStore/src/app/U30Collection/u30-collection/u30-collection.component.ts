import { Component } from '@angular/core';

@Component({
  selector: 'app-u30-collection',
  standalone: true,
  imports: [],
  templateUrl: './u30-collection.component.html',
  styleUrl: './u30-collection.component.css'
})
export class U30CollectionComponent {

}
