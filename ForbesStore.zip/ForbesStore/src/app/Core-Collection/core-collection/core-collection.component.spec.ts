import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoreCollectionComponent } from './core-collection.component';

describe('CoreCollectionComponent', () => {
  let component: CoreCollectionComponent;
  let fixture: ComponentFixture<CoreCollectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CoreCollectionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CoreCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
