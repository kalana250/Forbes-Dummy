import { Component } from '@angular/core';

@Component({
  selector: 'app-core-collection',
  standalone: true,
  imports: [],
  templateUrl: './core-collection.component.html',
  styleUrl: './core-collection.component.css'
})
export class CoreCollectionComponent {

}
