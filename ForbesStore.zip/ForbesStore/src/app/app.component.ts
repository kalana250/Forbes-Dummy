import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CoreCollectionComponent } from "./Core-Collection/core-collection/core-collection.component";
import { U30CollectionComponent } from "./U30Collection/u30-collection/u30-collection.component";
import { FwCollectionComponent } from "./ForbesWomenCollection/fw-collection/fw-collection.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, CoreCollectionComponent, U30CollectionComponent, FwCollectionComponent]
})
export class AppComponent {
  title = 'ForbesStore';
}
