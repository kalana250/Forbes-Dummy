import { Component } from '@angular/core';

@Component({
  selector: 'app-midas-list',
  standalone: true,
  imports: [],
  templateUrl: './midas-list.component.html',
  styleUrl: './midas-list.component.css'
})
export class MidasListComponent {

}
