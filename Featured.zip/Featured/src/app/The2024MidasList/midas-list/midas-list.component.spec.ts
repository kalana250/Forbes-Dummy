import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MidasListComponent } from './midas-list.component';

describe('MidasListComponent', () => {
  let component: MidasListComponent;
  let fixture: ComponentFixture<MidasListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MidasListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MidasListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
