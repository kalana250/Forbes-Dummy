import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MidasListComponent } from "./The2024MidasList/midas-list/midas-list.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, MidasListComponent]
})
export class AppComponent {
  title = 'Featured';
}
