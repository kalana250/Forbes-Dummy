import { Component } from '@angular/core';

@Component({
  selector: 'app-advertisment',
  standalone: true,
  imports: [],
  templateUrl: './advertisment.component.html',
  styleUrl: './advertisment.component.css'
})
export class AdvertismentComponent {

}
