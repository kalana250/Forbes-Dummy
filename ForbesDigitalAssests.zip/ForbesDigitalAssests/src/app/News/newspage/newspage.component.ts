import { Component } from '@angular/core';

@Component({
  selector: 'app-newspage',
  standalone: true,
  imports: [],
  templateUrl: './newspage.component.html',
  styleUrl: './newspage.component.css'
})
export class NewspageComponent {

}
