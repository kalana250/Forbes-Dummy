import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VFashionClothingComponent } from './v-fashion-clothing.component';

describe('VFashionClothingComponent', () => {
  let component: VFashionClothingComponent;
  let fixture: ComponentFixture<VFashionClothingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VFashionClothingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VFashionClothingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
