import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { VFashionClothingComponent } from "./VettedFashionClothing/v-fashion-clothing/v-fashion-clothing.component";
import { NewspageComponent } from "./News/newspage/newspage.component";

@Component({
    selector: 'app-root',
    standalone: true,
    templateUrl: './app.component.html',
    styleUrl: './app.component.css',
    imports: [RouterOutlet, VFashionClothingComponent, NewspageComponent]
})
export class AppComponent {
  title = 'ForbesDigitalAssests';
}
