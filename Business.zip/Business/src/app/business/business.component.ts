import { Component } from '@angular/core';

@Component({
  selector: 'app-business',
  standalone: true,
  imports: [],
  templateUrl: './business.component.html',
  styleUrl: './business.component.css'
})
export class BUSINESSComponent {
  ImageURL: string='https://imageio.forbes.com/specials-images/imageserve/668330a45df1cb586a9b473e/0x0.jpg?format=jpg&width=1100';
  img1: string='https://imageio.forbes.com/specials-images/imageserve/668330ca1895ce2eb1d43096/0x0.jpg?format=jpg&width=200';
  img2: string='https://imageio.forbes.com/specials-images/imageserve/668331075df1cb586a9b4742/0x0.jpg?format=jpg&width=200';
  img3: string='https://imageio.forbes.com/specials-images/imageserve/667edae29837c6f65709b394/0x0.jpg?format=jpg&width=200';
  img4: string='';
  Firstimage: string='https://imageio.forbes.com/specials-images/imageserve/66340a7f5b3489467cc52bbd/0x0.jpg?format=jpg';
  Secondimage: string='https://imageio.forbes.com/specials-images/imageserve/66340ab25ac414684e84a2bb/0x0.jpg?format=jpg';
  Thiredimage: string='https://imageio.forbes.com/specials-images/imageserve/66340a9725aad56457f0f2ae/0x0.jpg?format=jpg';
  rightImageURL1: string='https://imageio.forbes.com/specials-images/imageserve/668330b85df1cb586a9b4740/0x0.jpg?format=jpg&width=500';
  rightImageURL2: string='https://imageio.forbes.com/specials-images/imageserve/668330f0a7ec94629b0b2e6a/0x0.jpg?format=jpg&width=500';

}
