import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BUSINESSComponent } from './business.component';

describe('BUSINESSComponent', () => {
  let component: BUSINESSComponent;
  let fixture: ComponentFixture<BUSINESSComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BUSINESSComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BUSINESSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
