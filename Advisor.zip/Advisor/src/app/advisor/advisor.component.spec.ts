import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ADVISORComponent } from './advisor.component';

describe('ADVISORComponent', () => {
  let component: ADVISORComponent;
  let fixture: ComponentFixture<ADVISORComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ADVISORComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ADVISORComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
