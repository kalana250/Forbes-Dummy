import { Component } from '@angular/core';

@Component({
  selector: 'app-advisor',
  standalone: true,
  imports: [],
  templateUrl: './advisor.component.html',
  styleUrl: './advisor.component.css'
})
export class ADVISORComponent {

}
