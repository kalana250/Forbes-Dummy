import { Component } from '@angular/core';

@Component({
  selector: 'app-v-fashion-clothing',
  standalone: true,
  imports: [],
  templateUrl: './v-fashion-clothing.component.html',
  styleUrl: './v-fashion-clothing.component.css'
})
export class VFashionClothingComponent {

}
