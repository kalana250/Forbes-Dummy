import { Component } from '@angular/core';

@Component({
  selector: 'app-ai',
  standalone: true,
  imports: [],
  templateUrl: './ai.component.html',
  styleUrl: './ai.component.css'
})
export class AIComponent {

  bodyImageURL : string = "https://imageio.forbes.com/specials-images/imageserve/667c483599f389098e088300/0x0.jpg?format=jpg";
  Rivianimage : string = "https://imageio.forbes.com/specials-images/imageserve/667c486e99f389098e088302/0x0.jpg?format=jpg";
  AppStoreimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c48aab0822cc67a1612d8/0x0.jpg?format=jpg";
  Amazonimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c4ad3ea480ba00baf925e/0x0.jpg?format=jpg"
   
}
