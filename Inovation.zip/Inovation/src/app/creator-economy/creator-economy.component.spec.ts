import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CREATORECONOMYComponent } from './creator-economy.component';

describe('CREATORECONOMYComponent', () => {
  let component: CREATORECONOMYComponent;
  let fixture: ComponentFixture<CREATORECONOMYComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CREATORECONOMYComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CREATORECONOMYComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
