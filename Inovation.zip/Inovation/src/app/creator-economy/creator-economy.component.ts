import { Component } from '@angular/core';

@Component({
  selector: 'app-creator-economy',
  standalone: true,
  imports: [],
  templateUrl: './creator-economy.component.html',
  styleUrl: './creator-economy.component.css'
})
export class CREATORECONOMYComponent {
  bodyImageURL:string="https://imageio.forbes.com/specials-images/imageserve/667c69fab9439d81057d371d/0x0.jpg?format=jpg";
  Creatorimage : string = "https://imageio.forbes.com/specials-images/imageserve/667c6c7472f77ac0d1795d2e/0x0.jpg?format=jpg";
  Voiceimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c6ba3c761087485a437a9/0x0.jpg?format=jpg";
  Youtubeimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c6c93378c4b4b77cb195a/0x0.jpg?format=jpg";

}
