import { Component } from '@angular/core';

@Component({
  selector: 'app-consumer-tech',
  standalone: true,
  imports: [],
  templateUrl: './consumer-tech.component.html',
  styleUrl: './consumer-tech.component.css'
})
export class CONSUMERTECHComponent {
  bodyImageURL: string ="https://imageio.forbes.com/specials-images/imageserve/667c61fb46e26fbd07537c0c/0x0.jpg?format=jpg";
  Appleimage: string ="https://imageio.forbes.com/specials-images/imageserve/667c62570858919ba3c8a24d/0x0.jpg?format=jpg";
  Samsungimage:string="https://imageio.forbes.com/specials-images/imageserve/667c62aaa2c8434388d2dfbd/0x0.jpg?format=jpg";
  Obsbotimage:string="https://imageio.forbes.com/specials-images/imageserve/667c62c0da64b848056fe8f2/0x0.jpg?format=jpg";

}
