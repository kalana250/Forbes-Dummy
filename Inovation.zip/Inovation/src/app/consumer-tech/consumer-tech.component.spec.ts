import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CONSUMERTECHComponent } from './consumer-tech.component';

describe('CONSUMERTECHComponent', () => {
  let component: CONSUMERTECHComponent;
  let fixture: ComponentFixture<CONSUMERTECHComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CONSUMERTECHComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CONSUMERTECHComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
