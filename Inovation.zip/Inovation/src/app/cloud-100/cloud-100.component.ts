import { Component } from '@angular/core';

@Component({
  selector: 'app-cloud-100',
  standalone: true,
  imports: [],
  templateUrl: './cloud-100.component.html',
  styleUrl: './cloud-100.component.css'
})
export class CLOUD100Component {
  TheCloudimage : string = "https://media-s3-us-east-1.ceros.com/forbes/images/2023/08/03/3d74c60a21582c18cfddaf840699645e/blocks.jpg?imageOpt=1&fit=bounds&width=1500";
  SamAIimage : string = "https://static.vecteezy.com/system/resources/thumbnails/037/098/807/small_2x/ai-generated-a-happy-smiling-professional-man-light-blurry-office-background-closeup-view-photo.jpg";
  Rachelimage : string = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQIRBoKveRmaHbc1_5m2BkZeOM0A2E7ogogeIABNGbOVb7Slyw1TyiJihCeL56jx4v_m8&usqp=CAU";
  Arifimage : string = "https://t4.ftcdn.net/jpg/03/25/73/59/360_F_325735908_TkxHU7okor9CTWHBhkGfdRumONWfIDEb.jpg";
  Clementimage : string = "https://t4.ftcdn.net/jpg/01/56/19/15/360_F_156191504_F8KusEJnAdRbyztflKKtQnnU43GIyWv4.jpg";

}
