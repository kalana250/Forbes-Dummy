import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CLOUD100Component } from './cloud-100.component';

describe('CLOUD100Component', () => {
  let component: CLOUD100Component;
  let fixture: ComponentFixture<CLOUD100Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CLOUD100Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CLOUD100Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
