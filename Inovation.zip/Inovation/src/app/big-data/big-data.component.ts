import { Component } from '@angular/core';

@Component({
  selector: 'app-big-data',
  standalone: true,
  imports: [],
  templateUrl: './big-data.component.html',
  styleUrl: './big-data.component.css'
})
export class BigDataComponent {
  bodyImageURL : string = "https://imageio.forbes.com/specials-images/imageserve/66732e43e54b373fe7880c5b/0x0.jpg?format=jpg";
  Samsungimage : string = "https://imageio.forbes.com/specials-images/imageserve/66732efcad475a2687db8084/0x0.jpg?format=jpg";
  Personimage : string = "https://imageio.forbes.com/specials-images/imageserve/66732e908c7ec1dc5fdd1de5/0x0.jpg?format=jpg";
  Aiimage : string = "https://imageio.forbes.com/specials-images/imageserve/66732f966f60752be56d6bd2/0x0.jpg?format=jpg";

}
