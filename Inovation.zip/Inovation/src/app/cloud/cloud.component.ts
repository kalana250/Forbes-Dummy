import { Component } from '@angular/core';

@Component({
  selector: 'app-cloud',
  standalone: true,
  imports: [],
  templateUrl: './cloud.component.html',
  styleUrl: './cloud.component.css'
})
export class CLOUDComponent {
  bodyImageURL: string = "https://imageio.forbes.com/specials-images/imageserve/667c5c7efc001d3f48c1ea72/0x0.jpg?format=jpg";
  OpenAIimage : string = "https://imageio.forbes.com/specials-images/imageserve/667c5cc1bf384aa461af5fa6/0x0.jpg?format=jpg";
  SoftSkillimage : string ="https://imageio.forbes.com/specials-images/imageserve/667c5cecbf384aa461af5fa8/0x0.jpg?format=jpg";
  Focusimage : string = "https://imageio.forbes.com/specials-images/imageserve/667c5cd30858919ba3c8a244/0x0.jpg?format=jpg";

}
