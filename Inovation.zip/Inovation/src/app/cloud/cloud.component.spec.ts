import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CLOUDComponent } from './cloud.component';

describe('CLOUDComponent', () => {
  let component: CLOUDComponent;
  let fixture: ComponentFixture<CLOUDComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CLOUDComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CLOUDComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
