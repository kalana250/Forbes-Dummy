import { Component } from '@angular/core';

@Component({
  selector: 'app-innovation',
  standalone: true,
  imports: [],
  templateUrl: './innovation.component.html',
  styleUrl: './innovation.component.css'
})
export class INNOVATIONComponent {
  ImageURL: string='https://imageio.forbes.com/specials-images/imageserve/66855ab3291aaddec930d88b/0x0.jpg?format=jpg&width=1100';
  img1:string='https://imageio.forbes.com/specials-images/imageserve/66855adbde0ac8b97020d459/0x0.jpg?format=jpg&width=200';
  img2:string='https://imageio.forbes.com/specials-images/imageserve/667c5aefdb54761614859cdd/0x0.jpg?format=jpg&width=200';
  img3:string='https://imageio.forbes.com/specials-images/imageserve/6666f467e724f86ec1f61f51/0x0.jpg?format=jpg&width=200';
  img4:string='';
  Firstimage: string='https://imageio.forbes.com/specials-images/imageserve/6617fb7ee742542300a7f1d6/0x0.jpg?format=jpg';
  Secondimage: string='https://imageio.forbes.com/specials-images/imageserve/6666f48ee724f86ec1f61f53/0x0.jpg?format=jpg';
  Thiredimage: string='https://imageio.forbes.com/specials-images/imageserve/6617fbaf3dd4f5a061f4124b/0x0.jpg?format=jpg';
  Forthimage: string='https://imageio.forbes.com/specials-images/imageserve/6666f507ba43429cc1280f15/0x0.jpg?format=jpg';
  rightImageURL1:string='https://imageio.forbes.com/specials-images/imageserve/66855abf881cba7c6bc19255/0x0.jpg?format=jpg&width=500';
  rightImageURL2:string='https://imageio.forbes.com/specials-images/imageserve/66855acbde0d43b96d327bf2/0x0.jpg?format=jpg&width=500';


}
