import { Component } from '@angular/core';

@Component({
  selector: 'app-cybersecurity',
  standalone: true,
  imports: [],
  templateUrl: './cybersecurity.component.html',
  styleUrl: './cybersecurity.component.css'
})
export class CYBERSECURITYComponent {
  bodyImageURL: string ="https://imageio.forbes.com/specials-images/imageserve/667c6ddfaf9f10bb5babcadd/0x0.jpg?format=jpg";
  Metaimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c6e38af9f10bb5babcadf/0x0.jpg?format=jpg";
  Hackimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c6e4a8354d811ca6774db/0x0.jpg?format=jpg&crop=950,532,x0,y212,safe";
  Russianimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c6e603581de540326db67/0x0.jpg?format=jpg";

}
