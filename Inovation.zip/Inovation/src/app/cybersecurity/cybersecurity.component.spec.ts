import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CYBERSECURITYComponent } from './cybersecurity.component';

describe('CYBERSECURITYComponent', () => {
  let component: CYBERSECURITYComponent;
  let fixture: ComponentFixture<CYBERSECURITYComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CYBERSECURITYComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CYBERSECURITYComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
