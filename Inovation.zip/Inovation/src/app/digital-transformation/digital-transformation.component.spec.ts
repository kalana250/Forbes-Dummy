import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DIGITALTRANSFORMATIONComponent } from './digital-transformation.component';

describe('DIGITALTRANSFORMATIONComponent', () => {
  let component: DIGITALTRANSFORMATIONComponent;
  let fixture: ComponentFixture<DIGITALTRANSFORMATIONComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DIGITALTRANSFORMATIONComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DIGITALTRANSFORMATIONComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
