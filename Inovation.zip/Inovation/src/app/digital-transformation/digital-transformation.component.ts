import { Component } from '@angular/core';

@Component({
  selector: 'app-digital-transformation',
  standalone: true,
  imports: [],
  templateUrl: './digital-transformation.component.html',
  styleUrl: './digital-transformation.component.css'
})
export class DIGITALTRANSFORMATIONComponent {
  bodyImageURL: string="https://imageio.forbes.com/specials-images/imageserve/667c735a6673de04cc1a027c/0x0.jpg?format=jpg";
  Hybridimage: string = "https://imageio.forbes.com/specials-images/imageserve/667c72228e4618064b07369e/0x0.jpg?format=jpg";
  NTTimage: string ="https://imageio.forbes.com/specials-images/imageserve/667c72916da3b70949c39efb/0x0.jpg?format=jpg";
  Dataimage: string="https://imageio.forbes.com/specials-images/imageserve/667c73934a44454e19889582/0x0.jpg?format=jpg";

}
