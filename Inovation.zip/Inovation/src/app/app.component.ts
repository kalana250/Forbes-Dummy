import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { INNOVATIONComponent } from './innovation/innovation.component';
import { AIComponent} from './ai/ai.component';
import { BigDataComponent }  from './big-data/big-data.component';
import { CLOUDComponent } from './cloud/cloud.component';
import { CLOUD100Component } from './cloud-100/cloud-100.component';
import { CONSUMERTECHComponent } from './consumer-tech/consumer-tech.component';
import { CREATORECONOMYComponent } from './creator-economy/creator-economy.component';
import { CYBERSECURITYComponent } from './cybersecurity/cybersecurity.component';
import { DIGITALTRANSFORMATIONComponent } from './digital-transformation/digital-transformation.component';
import { ENTERPRICETECHComponent } from './enterprice-tech/enterprice-tech.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, INNOVATIONComponent, AIComponent, BigDataComponent,CLOUDComponent,CLOUD100Component, CONSUMERTECHComponent, CREATORECONOMYComponent, CYBERSECURITYComponent, DIGITALTRANSFORMATIONComponent, ENTERPRICETECHComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Inovation';
}
