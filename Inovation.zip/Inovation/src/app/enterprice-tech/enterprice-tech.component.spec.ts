import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ENTERPRICETECHComponent } from './enterprice-tech.component';

describe('ENTERPRICETECHComponent', () => {
  let component: ENTERPRICETECHComponent;
  let fixture: ComponentFixture<ENTERPRICETECHComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ENTERPRICETECHComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ENTERPRICETECHComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
