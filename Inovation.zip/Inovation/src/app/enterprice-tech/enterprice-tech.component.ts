import { Component } from '@angular/core';

@Component({
  selector: 'app-enterprice-tech',
  standalone: true,
  imports: [],
  templateUrl: './enterprice-tech.component.html',
  styleUrl: './enterprice-tech.component.css'
})
export class ENTERPRICETECHComponent {

}
